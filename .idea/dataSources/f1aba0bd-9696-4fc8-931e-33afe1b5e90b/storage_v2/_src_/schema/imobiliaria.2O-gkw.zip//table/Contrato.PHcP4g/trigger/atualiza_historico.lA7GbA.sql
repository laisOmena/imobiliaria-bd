create definer = root@`%` trigger atualiza_historico
    after INSERT
    on Contrato
    for each row
begin
   insert into Historico values();
   update Historico
            inner join Contrato
            on Contrato.numero = Historico.protocolo
            set datahistorico = curdate(), Historico.crecicorretor = Contrato.crecicorretor/*(select crecicorretor from contrato where contrato.numero = historico.protocolo)*/
            where Contrato.numero = Historico.protocolo;
  end;

